const fs = require('fs');
const path = require('path');
const mathjs = require('mathjs');
const { type } = require('os');
const { GuildMember } = require('discord.js');
require('dotenv').config();

class ServerRoleManager {
	// ### DATA MANAGEMENT ### //

	/** @param {string} guildId */
	constructor(guildId) {
		this.guildId = guildId;
		this.serverDataDir = path.join(process.env.YUFO_DATA_PATH || path.join(__dirname, '../data'), 'servers', guildId);
		this._cache = {}; // 'config': {}, 'members': new Map(), 'XP': { relative: [], total: [] }
		this._cacheCooldowns = { 'config': 10000, 'members': 10000, 'XP': 5000 };
		this._cacheLastSaves = { 'config': 0, 'members': 0, 'XP': 0 };
	}

	/** @type {Map<string, ServerRoleManager>} */
	static _instances = new Map();

	/**
	 * Creates a new instance of ServerRoleManager for the provided guildId if it doesn't already exist.
	 * Otherwise, returns the existing instance.
	 *
	 * @static
	 * @param {string} guildId
	 * @returns {ServerRoleManager} The instance of ServerRoleManager for the guild.
	 */
	static getInstance(guildId) {
		if (this._instances.has(guildId)) return this._instances.get(guildId);

		const serverRoleManager = new this(guildId);
		serverRoleManager.ensureGuildDirectory();
		this._instances.set(guildId, serverRoleManager);
		return serverRoleManager;
	}

	static saveAllCaches() {
		for (const [guildId, serverRoleManager] of this._instances.entries()) {
			try {
				console.log(`Saving config for guild ${guildId}`);
				serverRoleManager.saveConfig(true);
				console.log(`Saving members for guild ${guildId}`);
				serverRoleManager.saveMembers(true);
				console.log(`Saving XP cache for guild ${guildId}`);
				serverRoleManager.saveXPCache(true);
			} catch (error) {
				console.error(`Error saving cached data for guild ${guildId} during shutdown:`, error);
			}
		}
	}

	ensureGuildDirectory() {
		try {
			fs.mkdirSync(this.serverDataDir, { recursive: true });
		} catch (error) {
			if (error.code !== 'EEXIST') throw error;
		}
	}

	getDefaultConfig() {
		return {
			paths: {},
			xpFormula: {
				formulas: [ // Map()
					// x = last level relative xp, n = last level total xp, l = new level
					// X = new relative xp, N = new total xp, t = # of levels since last formula, B = first (base) n of current formula
					[1, "5"], // Constant value as baseline, first level-up (X = 5) (N = 5)
					[2, "x"], // Linear progression by default, copy of "5" (X = 5) (N = 5t + B)
					[10, "x+10"], // Quadratic progression, 10 more xp for each level (X = 15, 25, ...) (N = 10(t^2 + 2t)/2 + B)
					[20, "1.1x"], // Exponential progression, 10% more xp for each level (X = 115.5, 127.05 ...) (N = 1.1^t * x + n)
					[30, "0.1n"] // Exponential progression, 10% more total xp for each level (X = 2734.35, 3007.78, ...) (N = 1.1^t * n)
				],
				maxLevel: null  // Server-wide maximum level
			},
			defaultChannel: null,
			cacheConfigCooldown: this._cacheCooldowns.config, // Default 10 seconds cooldown
			cacheMembersCooldown: this._cacheCooldowns.members,  // 10s
			cacheXPCooldown: this._cacheCooldowns.XP,  // 5s
			xpSettings: {
				defaultMessageXP: 5,
				messageXP: [], // Map()
				defaultVoiceXP: {
					amount: 1,
					minutes: 5
				},
				voiceXP: [] // Map()
			}
		};
	}

	getDefaultMembers() {
		return []; // Map()
	}

	getDefaultXPCache() {
		return {
			relative: [],  // Map() cache for relative XP values
			total: []      // Map() cache for total XP values
		};
	}

	convertArrayPropertyToMap(object, property) {
		if (!object?.[property]) return;
		object[property] = new Map(object[property]);
	}

	// convertMapPropertyToArray(object, property) {
	// 	if (!object?.[property]) return new Map();
	// 	const oldValue = new Map(object[property]);
	// 	object[property] = Array.from(object[property]);
	// 	return oldValue; // Return copy of Map() for post-save
	// }

	loadConfig() {
		const cache = this._cache.config;

		// Return if members cache already exists in memory
		if (cache) return cache;

		// Load from file if not in memory
		const configPath = path.join(this.serverDataDir, 'config.json');
		let newData;

		try {
			const data = JSON.parse(fs.readFileSync(configPath, 'utf8'));
			newData = (data === null) ? this.getDefaultConfig() : data;
		} catch (error) {
			if (error.code !== 'ENOENT') {
				console.error(`Error loading config data for guild ${this.guildId}:`, error)
			}
			newData = this.getDefaultConfig();
		}

		// console.log(newData);

		try {
			this.convertArrayPropertyToMap(newData?.xpFormula, 'formulas');
			this.convertArrayPropertyToMap(newData?.xpSettings, 'messageXP');
			this.convertArrayPropertyToMap(newData?.xpSettings, 'voiceXP');
			if (newData?.paths) {
					for (const value of Object.values(newData.paths)) {
						this.convertArrayPropertyToMap(value, 'levels');
					}
			}
		} catch (error) {
			throw new Error(`Error converting config data for guild ${this.guildId}:`, error);
		}

		// console.log(`loaded config cache from file`, newData);
		// Store in memory
		this._cache.config = newData;
		return newData;
	}

	saveConfig(force=false) {
		const now = Date.now();
		const lastSave = this._cacheLastSaves.config || 0;
		const cooldown = this._cacheCooldowns.config;
		// Check if enough time has passed since last save
		if (!force && now - lastSave < cooldown) return;

		const config = this.loadConfig();
		if (!config) return;

		const cachePath = path.join(this.serverDataDir, 'config.json');
		try {
			const convertMapToArray = (property, value) => value instanceof Map ? Array.from(value) : value;

			fs.writeFileSync(cachePath, JSON.stringify(config, convertMapToArray, 2));
			this._cacheLastSaves.config = now;
		} catch (error) {
			console.error(`Error saving config cache for guild ${this.guildId}:`, error);
		}
	}

	loadMembers() {
		const members = this._cache.members;

		// Return if members cache already exists in memory
		if (members) return members;

		// Load from file if not in memory
		const membersPath = path.join(this.serverDataDir, 'members.json');
		let newData;

		try {
			const data = JSON.parse(fs.readFileSync(membersPath, 'utf8'));
			newData = (data === null) ? new Map(this.getDefaultMembers()) : new Map(data);
		} catch (error) {
			if (error.code !== 'ENOENT') {
				console.error(`Error loading member data for guild ${this.guildId}:`, error)
			}
			newData = new Map(this.getDefaultMembers());
		}

		// console.log(`loaded members cache from file`, newData);
		// Store in memory
		this._cache.members = newData;
		return newData;
	}

	saveMembers(force=false) {
		const now = Date.now();
		const lastSave = this._cacheLastSaves.members || 0;
		const cooldown = this._cacheCooldowns.members;
		// Check if enough time has passed since last save
		if (!force && now - lastSave < cooldown) return;

		const members = this._cache.members;
		if (!members) return;
		const cachePath = path.join(this.serverDataDir, 'members.json');
		try {
			fs.writeFileSync(cachePath, JSON.stringify([...members], null, 2)); // Convert Map to array
			this._cacheLastSaves.members = now;
		} catch (error) {
			console.error(`Error saving member cache for guild ${this.guildId}:`, error);
		}
	}

	loadXPCache() {
		const cache = this._cache.XP;

		// Check if XP cache exists in memory
		if (cache) return cache;

		// Load from file if not in memory
		const xpPath = path.join(this.serverDataDir, 'xpcache.json');
		let newData;

		try {
			const data = JSON.parse(fs.readFileSync(xpPath, 'utf8'));
			newData = (data === null) ? this.getDefaultXPCache() : { relative: data[0], total: data[1] };
		} catch (error) {
			if (error.code !== 'ENOENT') {
				console.error(`Error loading XP cache for guild ${this.guildId}:`, error)
			}
			newData = this.getDefaultXPCache();
		}

		// console.log(`loaded XP cache from file`, newData);
		// Store in memory
		this._cache.XP = newData;
		return newData;
	}

	saveXPCache(force=false) {
		const now = Date.now();
		const lastSave = this._cacheLastSaves.XP || 0;
		const cooldown = this._cacheCooldowns.XP;
		// Check if enough time has passed since last save
		if (!force && now - lastSave < cooldown) return;

		const cache = this.loadXPCache();
		if (!cache) return;

		const cachePath = path.join(this.serverDataDir, 'xpcache.json');
		try {
			fs.writeFileSync(cachePath, JSON.stringify([cache.relative, cache.total], null, 2));
			this._cacheLastSaves.XP = now;
		} catch (error) {
			console.error(`Error saving XP cache for guild ${this.guildId}:`, error);
		}
	}

	// ### XP FORMULAS ### //

	setXPFormula(expression, min, max = null) {
		const config = this.loadConfig();
		
		// Validate the expression by trying to evaluate it	
		try {
			// Test with some sample values
			this.calculateXP(expression, 1, { relative: 100, total: 100 });
		} catch (error) {
			throw new Error(`Invalid XP formula: ${error.message}`);
		}

		// Update server-wide max level if provided
		if (max !== null) {
			config.xpFormula.maxLevel = max;
		}

		// Add or update formula for this min level
		config.xpFormula.formulas.set(min, expression);

		// Reset cached values above min level when formulas change
		const cache = this.loadXPCache();
		if (cache) {
			cache.relative?.splice(min, cache.relative.length - min);
			cache.total?.splice(min, cache.total.length - min);
		}
		this.saveXPCache(true);
		this.saveConfig(true);

		return config;
	}

	removeXPFormula(level) {
		const config = this.loadConfig();
		const { formulas } = config.xpFormula;

		// Find the formula that applies to this level
		let formulaLevel = null;
		for (const [min, formula] of formulas) {
			if (level >= min && (!formula.max || level <= formula.max)) {
				formulaLevel = min;
				break;
			}
		}

		if (formulaLevel === null) {
			throw new Error(`No formula found for level ${level}`);
		}

		formulas.delete(formulaLevel);
		this.saveConfig(true);
		return config;
	}

	resetXPFormulas() {
		const config = this.loadConfig();
		const defaultConfig = this.getDefaultConfig();
		
		config.xpFormula = defaultConfig.xpFormula;
		this.saveConfig(true);
		return config;
	}

	getFormulaForLevel(formulas, level) {
		// Find the highest min level that's less than or equal to the current level
		let applicableMin = undefined;
		for (const [min, formula] of formulas) {
			if (level >= min) applicableMin = min;
		}
		
		if (applicableMin === undefined) {
			throw new Error(`No formula found for level ${level}`);
		}

		return formulas.get(applicableMin);
	}

	calculateXP(expression, level, previousXP) {
		const l = level;                // Current level
		const x = previousXP.relative;  // XP from previous level
		const n = previousXP.total;     // Total XP up to previous level

		try {
			return Math.max(0, mathjs.parse(expression).evaluate({ x, n, l }));
		} catch (error) {
			throw new Error(`Invalid expression: ${error.message}`);
		}
	}

	calculateLevelXP(level) {
		const config = this.loadConfig();
		const cache = this.loadXPCache();

		savingCache:
		// Calculate relative and total XP for this level
		if (level > 0 && (cache.relative[level] === undefined || cache.total[level] === undefined)) {
			// Get previous level's XP
			const previousXP = this.calculateLevelXP(level - 1);
			
			if (cache.relative[level] !== undefined) { // If relative XP is already cached while total is not
				cache.total[level] = previousXP.total + cache.relative[level];
				this.saveXPCache(true);
				break savingCache;
			}
			
			// Find the appropriate formula for this level
			const formula = this.getFormulaForLevel(config.xpFormula.formulas, level);

			// Calculate and cache this level's relative XP if not already cached
			cache.relative[level] = this.calculateXP(formula, level, previousXP);

			// Calculate total XP up to this level if not already cached
			if (cache.total[level] === undefined) cache.total[level] = previousXP.total + cache.relative[level];

			this.saveXPCache(true);
		}

		return {
			relative: cache.relative[level],
			total: cache.total[level]
		};
	}

	// ### ROLE MANAGEMENT ### //

	detectRoleChanges(memberData, initialLevel, newLevel, memberRoleManager) {
		const roleChanges = {
			remove: [],
			add: [],
			keep: []
		};

		if (initialLevel === newLevel || !memberData.path) return roleChanges;

		const guildId = this.guildId;
		const config = this.loadConfig();
		const path = config?.paths?.[memberData.path];
		
		if (!path) {
			console.log(`Path "${memberData.path}" not found for member in guild ${guildId}`);
			return roleChanges;
		}

		const isLevelingUp = newLevel > initialLevel;
		const pathLevels = Array.from(path.levels);
		const pathLevelsLength = pathLevels.length;
		const maxConfigLevel = Math.max(...pathLevels, config.xpFormula.maxLevel || Infinity);

		let isInitialLastRole = true;
		let isNewLastRole = true;

		const addToRemove = (roleData) => {
			if (memberRoleManager.cache.some(role => role.id === roleData.id)) {
				roleChanges.remove.push(roleData);
			}
		}
		const addToKeep = (roleData) => {
			((memberRoleManager.cache.some(role => role.id === roleData.id))
				? roleChanges.keep // If user already has this role, keep
				: roleChanges.add // Else add
			).push(roleData);
		}

		// Process roles from highest to lowest level
		for (let i = pathLevelsLength - 1; i >= 0; i--) {
			const roleLevel = pathLevels[i][0];
			const roleData = this.findRoleForLevel(memberData.path, roleLevel, memberRoleManager); // Correct any role ID or name discrepancies

			if (!roleData) continue;

			if (isLevelingUp) {
				if (initialLevel >= roleLevel) {
					if (isInitialLastRole) {
						isInitialLastRole = false;
						if (!isNewLastRole && !roleData.keep) {
							addToRemove(roleData);
						} else if (roleData.keep || isNewLastRole) {
							addToKeep(roleData);
						}
					} else if (roleData.keep) {
						addToKeep(roleData);
					}
				} else if (newLevel >= roleLevel) {
					if (isNewLastRole || roleData.keep) {
						isNewLastRole = false;
						addToKeep(roleData);
					}
				}
			} else {
				if (newLevel >= roleLevel) {
					if (isNewLastRole) {
						isNewLastRole = false;
						if (!roleData.keep) {
							addToKeep(roleData);
						} else {
							addToKeep(roleData);
						}
					} else if (roleData.keep) {
						addToKeep(roleData); // Redundant, I know, but clearer
					}
				} else if (initialLevel >= roleLevel) {
					if (isInitialLastRole) {
						isInitialLastRole = false;
						addToRemove(roleData);
						if (roleData.keep && !isNewLastRole) {
							addToRemove(roleData);
						}
					} else if (roleData.keep) {
						addToRemove(roleData);
					}
				}
			}
		}

		return roleChanges;
	}

	/**
	 *
	 *
	 * @param {GuildMember} member
	 * @param {string} operation
	 * @param {int} amount
	 * @returns 
	 * @memberof ServerRoleManager
	 */
	updateMemberXP(member, operation, amount) {
		const userId = member.id;
		const memberRoleManager = member.roles;

		const membersData = this.loadMembers();
		const config = this.loadConfig();

		let memberData = membersData.get(userId);
		if (!memberData) {
			memberData = { level: 0, xp: 0 };
			membersData.set(userId, memberData);
			this.saveMembers();
		}

		switch (operation) {
			case 'add':
				memberData.xp += amount;
				break;
			case 'remove':
				memberData.xp = Math.max(0, memberData.xp - amount);
				break;
			case 'set':
				memberData.xp = Math.max(0, amount);
				break;
			case 'reset':
				memberData.xp = 0;
				break;
			default:
				throw new Error(`Invalid operation: ${operation}`);
		}

		const initialLevel = memberData.level;
		const maxLevel = config.xpFormula.maxLevel;

		// Calculate new level based on XP
		let newLevel = memberData.level;
		let levelDiff = 0;
		if (operation !== 'reset') {
			console.log(`XP: ${memberData.xp}, Level: ${memberData.level}`);
			// Calculate XP requirements for surrounding levels
			while (!maxLevel || newLevel < maxLevel) {
				const nextLevelXP = this.calculateLevelXP(newLevel + 1);
				console.log(`Next Level XP: ${nextLevelXP.total}`);
				if (memberData.xp >= nextLevelXP.total) {
					newLevel++;
					levelDiff++;
				} else {
					break;
				}
			}
			while (newLevel > 0) {
				const currentLevelXP = this.calculateLevelXP(newLevel);
				if (memberData.xp < currentLevelXP.total) {
					newLevel--;
					levelDiff--;
				} else {
					break;
				}
			}
		} else {
			newLevel = 0;
			levelDiff -= initialLevel;
		}

		// If level changed, update member data and handle role changes
		if (levelDiff) {
			memberData.level = newLevel;
			
			const result = this.detectAndSetPath(userId, memberRoleManager, newLevel, initialLevel);

			return {
				memberData,
				levelDiff,
				roleChanges: result.roleChanges
			};
		}

		return {
			memberData,
			levelDiff: 0,
			roleChanges: {
				remove: [],
				add: [],
				keep: []
			}
		};
	}

	updateMemberLevel(member, operation, amount) {
		const userId = member.id;
		const memberRoleManager = member.roles;

		console.log(`Setting level - Member: ${userId}, Operation: ${operation}, Amount: ${amount}`);

		const membersData = this.loadMembers();
		const config = this.loadConfig();

		let memberData = membersData.get(userId);
		if (!memberData) {
			memberData = { level: 0, xp: 0 };
			membersData.set(userId, memberData);
		}
		
		const maxLevel = config.xpFormula.maxLevel;
		const initialLevel = memberData.level;
		let newLevel = memberData.level;

		switch (operation) {
			case 'add':
				newLevel = Math.min(maxLevel || Infinity, memberData.level + amount);
				break;
			case 'remove':
				newLevel = Math.max(0, memberData.level - amount);
				break;
			case 'set':
				if (maxLevel !== null && amount > maxLevel) {
					throw new Error(`Level must be between 0 and ${maxLevel}`);
				}
				newLevel = Math.max(0, amount);
				break;
			case 'reset':
				memberData.xp = 0;
				newLevel = 0;
				break;
			default:
				throw new Error(`Invalid operation: ${operation}`);
		}

		const levelDiff = newLevel - initialLevel;

		memberData.level = newLevel;

		// Set XP to the minimum required for this level
		const levelXP = this.calculateLevelXP(newLevel);
		memberData.xp = levelXP.total;

		this.saveMembers();

		// Detect and set path, handling role changes
		const result = this.detectAndSetPath(userId, memberRoleManager, newLevel, initialLevel);

		return { 
			memberData,
			levelDiff,
			roleChanges: result.roleChanges
		};
	}

	findRoleForLevel(pathId, roleLevel, roleManager = null) {
		const config = this.loadConfig();
		const path = config.paths?.[pathId];
		
		if (!path) return null;

		const roleData = path.levels?.get(roleLevel);
		if (!roleData) return null;

		// If guild or member role manager is provided, check for mismatches and update
		if (roleManager) {
			const currentRole = roleManager.cache.find(r => r.id === roleData.id || r.name === roleData.name);
			
			if (currentRole && (currentRole.id !== roleData.id || currentRole.name !== roleData.name)) {
				// Update role data with current values
				const updatedRoleData = {
					...roleData,
					id: currentRole.id,
					name: currentRole.name
				};
				
				// Update config
				config.paths[pathId].levels.set(roleLevel, updatedRoleData);
				this.saveConfig(true);
				
				return updatedRoleData;
			}
		}
		
		return roleData;
	}

	getRolesForPath(pathId, guildRoleManager) {
		const config = this.loadConfig();
		if (!config.paths[pathId]) {
			throw new Error(`Path ${pathId} does not exist`);
		}

		return Array.from(config.paths[pathId].levels).map(([level, _]) => {
			const role = this.findRoleForLevel(pathId, level, guildRoleManager); // Correct any role ID or name discrepancies
			return {
				level: level,
				id: role.id,
				name: role.name,
				keep: role.keep
			};
		});
	}

	detectAndSetPath(userId, memberRoleManager, newLevel, initialLevel) {
		const config = this.loadConfig();
		const membersData = this.loadMembers();

		// console.log('memberRoles', memberRoles);
		
		const memberData = membersData.get(userId);
		if (!memberData) {
			membersData.set(userId, { level: 0, xp: 0 });
		}
		
		if (!newLevel) newLevel = memberData.level;
		const memberRoleIds = memberRoleManager.cache.map(role => role.id);
		
		// Loop through each path in config
		for (const [pathId, pathData] of Object.entries(config.paths)) {
			// Check each level in the path
			for (const [level, roleData] of pathData.levels) {
				// If user has this role, they belong to this path
				if (memberRoleIds.includes(roleData.id)) {
					const oldPath = memberData.path;
					memberData.path = pathId;
					
					// // Set member's level to the highest level role they have in this path
					// const numLevel = parseInt(level);
					// if (!memberLevel || numLevel > memberLevel) {
					// 	memberLevel = numLevel;
					// }
					
					// Save the changes
					this.saveMembers();
					
					// If path changed, handle role changes
					if (oldPath !== pathId) {
						// Remove roles from old path if it exists
						let removeRoles = [];
						if (oldPath && config.paths[oldPath]) {
							// Get all roles from old path
							config.paths[oldPath].levels.forEach((role, level) => {
								if (memberRoleIds.includes(role.id)) {
									removeRoles.push(role.id);
								}
							});
						}
						
						// Get correct roles for new path and level
						const newPathRoleChanges = this.detectRoleChanges(memberData, 0, newLevel, memberRoleManager);
						newPathRoleChanges.remove.push(...removeRoles);
						
						return {
							pathChanged: true,
							oldPath,
							newPath: pathId,
							level: newLevel,
							roleChanges: newPathRoleChanges
						};
					}
				}
			}
		}
		
		// No path change
		return {
			pathChanged: false,
			path: null,
			level: newLevel,
			roleChanges: this.detectRoleChanges(memberData, initialLevel, newLevel, memberRoleManager)
		};
	}

	getMemberData(memberId) {
		return this.loadMembers().get(memberId) || null;
	}

	getAvailablePaths() {
		const config = this.loadConfig();
		return Object.values(config.paths);
	}

	getMemberLevel(memberId) {
		const members = this.loadMembers();
		return members[memberId] ? members[memberId].level : null;
	}

	// ### CONFIG MANAGEMENT ### //

	ensureLevelOrder(levelMap) {
		return new Map(Array.from(levelMap).sort((a, b) => a[0] - b[0]));
	}

	ensureLevelOrderForFormula() {
		const config = this.loadConfig();
		const formula = config.xpFormula?.formulas;
		if (!formula) {
			throw new Error(`This server (${this.guildId}) does not have any XP formulas configured`);
		}
		config.xpFormula.formulas = this.ensureLevelOrder(formula);
		this.saveConfig(true);
	}

	ensureLevelOrderForPath(pathId) {
		const config = this.loadConfig();
		const path = config.paths?.[pathId];
		if (!path) {
			throw new Error(`Path ${pathId} does not exist`);
		}
		path.levels = this.ensureLevelOrder(path.levels);
		this.saveConfig(true);
	}

	createPathInConfig(pathId, displayName = pathId) {
		const config = this.loadConfig();
		if (config.paths?.[pathId]) {
			throw new Error(`Path ${pathId} already exists`);
		}
		config.paths[pathId] = {
			id: pathId,
			name: displayName,
			levels: new Map()
		};
		this.saveConfig(true);
		return config;
	}

	deletePathInConfig(pathId) {
		const config = this.loadConfig();
		if (!config.paths?.[pathId]) {
			throw new Error(`Path ${pathId} does not exist`);
		}
		delete config.paths[pathId];
		this.saveConfig(true);
		return config;
	}

	editPathInConfig(pathId, newName, newId) {
		const config = this.loadConfig();
		if (!config.paths?.[pathId]) {
			throw new Error(`Path ${pathId} does not exist`);
		}

		// Update path ID
		if (newId && pathId !== newId) {
			config.paths[newId] = config.paths[pathId];
			config.paths[newId].id = newId;
			delete config.paths[pathId];
			pathId = newId;
		}

		let pathName = config.paths[pathId].name;
		// Update path name
		if (newName && pathName !== newName) {
			config.paths[pathId].name = newName;
			pathName = newName;
		}

		this.ensureLevelOrderForPath(pathId);
		return [ pathId, pathName ];
	}

	addRoleToConfig(pathId, roleLevel, roleId, roleName, keep = false) {
		const config = this.loadConfig();
		if (!config.paths?.[pathId]) {
			throw new Error(`Path ${pathId} does not exist`);
		}
		if (!config.paths[pathId].levels) {
			config.paths[pathId].levels = new Map();
		} else if (config.paths[pathId].levels.get(roleLevel)) {
			throw new Error(`Role with level ${roleLevel} already exists in path ${config.paths[pathId].name}`);
		}
		config.paths[pathId].levels.set(roleLevel, {
			id: roleId,
			name: roleName,
			keep
		});
		this.ensureLevelOrderForPath(pathId);
		return config;
	}

	removeRoleFromConfig(pathId, roleLevel) {
		const config = this.loadConfig();
		if (!config.paths?.[pathId]) {
			throw new Error(`Path ${pathId} does not exist`);
		}

		if (!config.paths[pathId].levels) {
			throw new Error(`Path ${config.paths[pathId].name} does not have any roles`);
		}
		// Find role by level
		const roleData = config.paths[pathId].levels.get(roleLevel);
		if (!roleData) {
			throw new Error(`Role with level ${roleLevel} not found in path ${config.paths[pathId].name}`);
		}

		config.paths[pathId].levels.delete(roleLevel);
		this.saveConfig(true);
		return roleData;
	}

	editRoleInConfig(pathId, roleLevel, updates, newLevel=null) {
		const config = this.loadConfig();
		if (!config.paths?.[pathId]) {
			throw new Error(`Path ${pathId} does not exist`);
		}

		if (!config.paths[pathId].levels) {
			throw new Error(`Path ${config.paths[pathId].name} does not have any roles`);
		}
		// Find role by level
		const roleData = config.paths[pathId].levels?.get(roleLevel);
		if (!roleData) {
			throw new Error(`Role with level ${roleLevel} not found in path ${config.paths[pathId].name}`);
		}

		// Update the role properties
		if (newLevel && roleLevel !== newLevel) {
			config.paths[pathId].levels.set(newLevel, {
				...roleData,
				...updates
			});
			config.paths[pathId].levels.delete(roleLevel);
		} else {
			config.paths[pathId].levels.set(roleLevel, {
				...roleData,
				...updates
			});
		}

		this.ensureLevelOrderForPath(pathId);
		return config;
	}
}

module.exports = ServerRoleManager;