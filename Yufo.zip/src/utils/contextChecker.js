module.exports = {
    hasPermission: (interaction, permission) =>
        interaction.member ?
        interaction.member.permissionsIn(interaction.channel).has(permission) :
        true,
    getDirectMessageChannel: async (user) =>
        user.dmChannel || await user.createDM()
}