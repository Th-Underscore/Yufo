const fs = require('fs');

// const xp = fs.readFileSync('./src/data/servers/798919717297324042/cache.json');
// console.log(xp);
// const json = JSON.parse(xp);
// console.log(json.relative);
// const ar = [[], []];
// Object.entries(json.relative).forEach(([key, value]) => {
//	 ar[0][parseInt(key)] = value;
// });
// Object.entries(json.total).forEach(([key, value]) => {
//	 ar[1][parseInt(key)] = value;
// });
 

// fs.writeFileSync('./src/data/servers/798919717297324042/xpcache.json', JSON.stringify(ar, null, 2));

// const testObject = {"property": [[1, "test"]]};
// function convertArrayPropertyToMap(object, property) {
//	 if (!object?.[property]) return;
//	 object[property] = new Map(object[property]);
// }
// convertArrayPropertyToMap(testObject, 'property');
// console.log(testObject);

// const ar2 = [];
// ar2[5] = 1;
// console.log(JSON.stringify(ar2));
// delete ar2[5];
// console.log(JSON.stringify(ar2));

// const map = new Map();
// map.set('a', 1);
// map.set('b', 2);
// map.set('c', 3);
// console.log(map);

// const test = { aMap: map };

// console.log(JSON.stringify(test, (_, value) => value instanceof Map ? Array.from(value) : value));
// console.log(test.aMap);

console.log(undefined ?? 'false')